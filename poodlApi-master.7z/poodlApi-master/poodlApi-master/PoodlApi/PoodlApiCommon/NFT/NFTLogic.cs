﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace PoodlApiCommon.NFT
{

    public class NFTAsset
    {
        public string Name { get; set; }
        public string Id { get; set; }
        public string ThumbnailUrl { get; set; }
        public string ModelUrl { get; set; }
        public string ContractAddress { get; set; }
        public string OwnerAddress { get; set; }
    }

    public class NFTCatalog
    {
        public List<NFTAsset> Assets { get; set; }
    }

    public class NFTLogic
    {
        public List<NFTAsset> nftList;
        public NFTLogic()
        {
            nftList = new List<NFTAsset>();
            for (int i = 0; i < 76; i++)
            {
                nftList.Add(this.GetNFTAsset(i.ToString()));
            }
        }

        public NFTAsset GetNFTAsset(string id, string userWallet = "0")
        {
            var asset = new NFTAsset()
            {
                Name = "Poodl_" + id,
                Id = id,
                ThumbnailUrl = "https://xlmoose.com/nft/poodl_3d_nft/thumbnails/" + id + ".png",
                ModelUrl = "https://xlmoose.com/nft/poodl_3d_nft/models/" + id + ".glb",
                ContractAddress = "0x495f947276749Ce646f68AC8c248420045cb7b5e",
                OwnerAddress = userWallet
            };
            return asset;
        }


    }
}
