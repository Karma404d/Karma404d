﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using PoodlApiCommon.NFT;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace PoodlApi.Controllers
{
    [DisableCors]
    [Route("api/[controller]")]
    [ApiController]
    public class NFTController : ControllerBase
    {
        NFTLogic _logic;
        public NFTController(NFTLogic logic)
        {
            _logic = logic ?? throw new ArgumentNullException(nameof(logic));
        }

        // GET api/values
        [HttpGet("catalog/{userWallet}")]
        public async Task<ActionResult<NFTCatalog>> GetCatalog(string userWallet)
        {
            var results = new NFTCatalog()
            {
                Assets = _logic.nftList
            };
            // This will use mock data for now
            
            return results;
        }

        // These endpoints are not ready
        
        //[HttpGet("modelAsset/{modelId}/version/{modelVersion}")]
        //public async Task<ActionResult<FileContentResult>> GetNftContents(string modelId, string modelVersion)
        //{

        //    //FileStreamResult result = null;
        //    var uri = "https://xlmoose.com/nft/poodl_3d_nft/models/variation4_pose0.glb";

        //    var fileStream = new MemoryStream();
        //    try
        //    {
        //        var imageUrl = uri;
        //        var request = (HttpWebRequest)WebRequest.Create(imageUrl);
        //        var response = (HttpWebResponse)request.GetResponse();

        //        if (response.StatusCode != HttpStatusCode.OK) throw new Exception("Unable to retrieve file.");
        //        using (var stream = response.GetResponseStream())
        //        {
        //            using (var tempStream = new MemoryStream())
        //            {

        //                stream.CopyTo(tempStream);
        //                fileStream = new MemoryStream(tempStream.ToArray(), false);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new ArgumentException("Unable to stream file.", uri, ex);
        //    }
        //    return base.File(fileStream, "model/gltf-binary", "filename.glb");
        //}

        //[HttpGet("imageAsset/{modelId}/version/{imageVersion}")]
        //public async Task<ActionResult<FileContentResult>> GetNftThumbnail(string modelId, string imageVersion)
        //{

        //    //FileStreamResult result = null;
        //    var uri = "https://xlmoose.com/nft/poodl_3d_nft/thumbnails/variation4.png";

        //    var fileStream = new MemoryStream();
        //    try
        //    {
        //        var imageUrl = uri;
        //        var request = (HttpWebRequest)WebRequest.Create(imageUrl);
        //        var response = (HttpWebResponse)request.GetResponse();

        //        if (response.StatusCode != HttpStatusCode.OK) throw new Exception("Unable to retrieve file.");
        //        using (var stream = response.GetResponseStream())
        //        {
        //            using (var tempStream = new MemoryStream())
        //            {

        //                stream.CopyTo(tempStream);
        //                fileStream = new MemoryStream(tempStream.ToArray(), false);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new ArgumentException("Unable to stream file.", uri, ex);
        //    }
        //    return base.File(fileStream, "	image/png", "filename.png");
        //}
    }
}
