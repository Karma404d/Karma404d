﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PoodlApi
{
    public class AppConfig
    {
        //public ConnectionStrings ConnectionStrings { get; set; }
    }

    //public class ConnectionStrings
    //{
    //    public string MainDbConnection { get; set; }
    //}

}
