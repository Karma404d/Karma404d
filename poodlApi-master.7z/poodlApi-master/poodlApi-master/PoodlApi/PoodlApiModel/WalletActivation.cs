﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PoodlApiModel
{
    public class WalletActivation
    {
        public Guid id { get; set; }
        public string walletAddress { get; set; }
        public string activationCode { get; set; }
        public string activationSource { get; set; }
        public DateTimeOffset generatedTime { get; set; }
        public DateTimeOffset? activatedTime { get; set; }
    }
}
