﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PoodlApiModel.Migrations
{
    public partial class AddingPfp : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PfpUrl",
                table: "PoodlTweets",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PfpUrl",
                table: "PoodlTweets");
        }
    }
}
