﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PoodlApiModel.Migrations
{
    public partial class initialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PoodlTweets",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ScreenName = table.Column<string>(nullable: true),
                    TweetId = table.Column<long>(nullable: false),
                    Created = table.Column<DateTimeOffset>(nullable: false),
                    IsRT = table.Column<bool>(nullable: false),
                    IsQRT = table.Column<bool>(nullable: false),
                    FavoriteCount = table.Column<int>(nullable: false),
                    RTCount = table.Column<int>(nullable: false),
                    Url = table.Column<string>(nullable: true),
                    RawSearchTermsList = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PoodlTweets", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PoodlTweets");
        }
    }
}
