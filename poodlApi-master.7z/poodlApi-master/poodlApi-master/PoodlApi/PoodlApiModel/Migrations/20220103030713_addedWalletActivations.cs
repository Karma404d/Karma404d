﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PoodlApiModel.Migrations
{
    public partial class addedWalletActivations : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "WalletActivations",
                columns: table => new
                {
                    id = table.Column<Guid>(nullable: false),
                    walletAddress = table.Column<string>(nullable: true),
                    activationCode = table.Column<string>(nullable: true),
                    activationSource = table.Column<string>(nullable: true),
                    generatedTime = table.Column<DateTimeOffset>(nullable: false),
                    activatedTime = table.Column<DateTimeOffset>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WalletActivations", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "WalletActivations");
        }
    }
}
