﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.DependencyInjection;

namespace PoodlApiModel
{
    public class PoodlApiModelContext : DbContext
    {
        public PoodlApiModelContext(DbContextOptions<PoodlApiModelContext> options) : base(options) { }

        public virtual DbSet<PoodlTweet> PoodlTweets { get; set; }
        public virtual DbSet<WalletActivation> WalletActivations { get; set; }



        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        /// <summary>
        /// Configure the service collection to include the db context
        /// </summary>
        /// <param name="services"></param>
        /// <param name="connection"></param>
        public static void ConfigureServiceCollection(IServiceCollection services, string connection)
        {
            services.AddDbContext<PoodlApiModelContext>(options =>
            {
                options.UseSqlServer(
                    connection,
                    builder => {
                        builder.MigrationsAssembly(typeof(PoodlApiModelContext).Assembly.FullName);
                    }
                    );
            });

        }

        /// <summary>
        /// Configure the provided db options builder to access the database that the context.
        /// </summary>
        /// <param name="options"></param>
        /// <param name="connection"></param>
        public static void ConfigureDbOptionsBuilder(DbContextOptionsBuilder options, string connection)
        {
            options.UseSqlServer(
                    connection,
                    builder => {
                        builder.MigrationsAssembly(typeof(PoodlApiModelContext).Assembly.FullName);
                    }
                    );
        }
    }
}
