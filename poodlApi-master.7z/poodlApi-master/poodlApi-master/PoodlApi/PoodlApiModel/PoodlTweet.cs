﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace PoodlApiModel
{
    public class PoodlTweet
    {
        public Guid Id { get; set; }
        public string ScreenName { get; set; }
        public long TweetId { get; set; }
        public DateTimeOffset Created { get; set; }
        public bool IsRT { get; set; }
        public bool IsQRT { get; set; }
        public int FavoriteCount { get; set; }
        public int RTCount { get; set; }
        public string Url { get { return $"http://www.twitter.com/{ScreenName}/status/{TweetId}"; } set { } }
        public string PfpUrl { get; set; }

        [NotMapped]
        public List<string> SearchTerms
        {
            get 
            {
                if (!string.IsNullOrEmpty(RawSearchTermsList))
                {
                    return JsonConvert.DeserializeObject<List<string>>(RawSearchTermsList);
                }
                else
                {
                    return new List<string>();
                }
            }

            set
            {
                if (value != null)
                {
                    RawSearchTermsList = JsonConvert.SerializeObject(value);
                }
            }
        }

        public string RawSearchTermsList { get; set; }
    }
}
